package myjpa.demo;

import java.io.Serializable;
import java.util.Vector;

public class Table implements Serializable {
    private final Vector<Linkman> tableinfo;
    //对应初始化列表
    public Table(){
        tableinfo = new Vector<Linkman>();
        //可以选择对自己的列表联系人初始化一些联系人出来，也可以选择只是一个空表
//        tableinfo.add(new Linkman(
//                "梁奥博", "17333695199", "915799721@qq.com", "北京市海淀区北太平庄街道西土城路10号", "915799721"
//        ));
    }
    //返回当前的列表全内容
    public Vector<Linkman> getTable(){
        return tableinfo;
    }
}