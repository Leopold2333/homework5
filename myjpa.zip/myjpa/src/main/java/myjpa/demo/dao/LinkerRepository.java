package myjpa.demo.dao;

import myjpa.demo.entity.Linker;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface LinkerRepository extends CrudRepository<Linker, Long> {
    List<Linker> findByMessage(String message);
    void deleteById(Long id);
}
