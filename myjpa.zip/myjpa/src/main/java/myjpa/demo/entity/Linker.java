package myjpa.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Linker {
    @Id
    private Long id;
    private String name,tel,email,address,QQ,message;

    public Linker(Long id, String name, String tel, String email, String address, String QQ, String message) {
        setId(id);
        setName(name);
        setTel(tel);
        setEmail(email);
        setAddress(address);
        setQQ(QQ);
        setMessage(message);
    }
    public Linker(){};

    public void setId(Long id){ this.id = id; }
    public void setName(String name){ this.name = name; }
    public void setTel(String tel){ this.tel = tel; }
    public void setEmail(String email){ this.email = email; }
    public void setAddress(String address){ this.address = address; }
    public void setQQ(String QQ){ this.QQ = QQ; }
    public void setMessage(String message){ this.message = message; }
    public Long getId(){ return id; }
    public String getName(){ return name; }
    public String getTel(){ return tel; }
    public String getEmail(){ return email; }
    public String getAddress(){ return address; }
    public String getQQ(){ return QQ; }
    public String getMessage(){ return message; }
}
