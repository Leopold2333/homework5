package myjpa.demo.controller;

import myjpa.demo.Linkman;
import myjpa.demo.Table;
import myjpa.demo.changeTable;
import myjpa.demo.dao.LinkerRepository;
import myjpa.demo.entity.Linker;
import net.bytebuddy.TypeCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class LinkerController {
    private LinkerRepository linkerRepository;
    @Autowired
    public void setLinkerRepository(LinkerRepository linkerRepository){
        this.linkerRepository = linkerRepository;
    }

    @GetMapping("/list")
    public String showMain(HttpServletRequest request){
        Object flag = request.getSession().getAttribute("login");
        if(null != flag){
            HttpSession session = request.getSession();
            session.removeAttribute("table");
            Table table = new Table();
            List<Linker> linkerList = linkerRepository.findByMessage("请按要求填写");
            for(int i=linkerList.size()-1;i>=0;i--){
                System.out.println(linkerList.get(i).getId());
                linkerRepository.deleteById(linkerList.get(i).getId());
            }
            for(int i=0;i<linkerList.size();i++){
                Linkman linkman = new Linkman(
                        linkerList.get(i).getName(),
                        linkerList.get(i).getTel(),
                        linkerList.get(i).getEmail(),
                        linkerList.get(i).getAddress(),
                        linkerList.get(i).getQQ(),
                        linkerList.get(i).getMessage()
                );
                table.getTable().addElement(linkman);
                Linker linker = new Linker(
                        (long)(i+1),linkerList.get(i).getName(),
                        linkerList.get(i).getTel(),linkerList.get(i).getEmail(),
                        linkerList.get(i).getAddress(),linkerList.get(i).getQQ(),
                        linkerList.get(i).getMessage()
                );
                linkerRepository.save(linker);
            }
            session.setAttribute("table",table);
            return "list";
        }
        else
            return "redirect:/login";
    }
    //点击“增加”按钮，会出发add选项
    @PostMapping("/add")
    public String showAdd(Linkman linkman, Model model){
        //建立一个联系人模型，交给add.html渲染处理
        model.addAttribute("linkman",linkman);
        return "add";
    }
    //add.html点击提交，进行检查
    @PostMapping({"/checkadd"})
    public String checkAdd(Linkman linkman, HttpServletRequest request, Model model){
        Table t = (Table)request.getSession().getAttribute("table");
        boolean isvalid = changeTable.checkAdd(t,linkman);
        if(isvalid){
            int count = t.getTable().size()+1;
            System.out.println((long) count);
            t.getTable().addElement(linkman);
            Linker linker = new Linker(
                    (long) count, linkman.getName(),linkman.getTel(),linkman.getEmail(),
                    linkman.getAddress(),linkman.getQQ(),"请按要求填写"
            );
            linkerRepository.save(linker);
            return "redirect:/list";
        }
        else{
            linkman.setMessage("联系人已存在");
            linkman.setName("");
            return showAdd(linkman,model);
        }
    }
    @PostMapping("/del")
    public String DeleteLinkman(@ModelAttribute(value="row")Integer row, HttpServletRequest request){
        linkerRepository.deleteById(Long.valueOf(row));
        return "redirect:/list";
    }
    //点击"修改"按钮
    @PostMapping("/change")
    public String showChange(@ModelAttribute(value="row")Integer row, HttpServletRequest request, Model model){
        linkerRepository.deleteById(Long.valueOf(row));
        //修改会将当前列表行传过去
        Table t = (Table)request.getSession().getAttribute("table");
        //利用这一行列表实例化一个联系人对象
        Linkman linkman = t.getTable().elementAt(row-1);
        //将联系人对象传给change.html以便修改
        model.addAttribute("linkman",linkman);
        return "change";
    }
    @PostMapping("checkchange")
    public String checkChange(Linkman linkman, HttpServletRequest request, Model model){
        Table t = (Table)request.getSession().getAttribute("table");
        int count = t.getTable().size()+1;
        System.out.println((long) count);
        t.getTable().addElement(linkman);
        Linker linker = new Linker(
                (long) count, linkman.getName(),linkman.getTel(),linkman.getEmail(),
                linkman.getAddress(),linkman.getQQ(),"请按要求填写"
        );
        linkerRepository.save(linker);
        return "redirect:/list";
    }
}
