package myjpa.demo.controller;

import myjpa.demo.Linkman;
import myjpa.demo.Table;
import myjpa.demo.changeTable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//访问添加页面、判断修改状态页面，在Session中创建和add.html传递数据的类linkman
@Controller
public class changeController {
    //通过导航栏直接访问
    @GetMapping({"add","/checkadd","/change","/checkchange","/del"})
    public String goBack(HttpServletRequest request){
        Object flag = request.getSession().getAttribute("login");
        if(null != flag){
            HttpSession session = request.getSession();
            if(null == session.getAttribute("table")){
                Table table = new Table();
                session.setAttribute("table",table);
            }
            return "redirect:/list";
        }
        else
            return "redirect:/login";
    }
}