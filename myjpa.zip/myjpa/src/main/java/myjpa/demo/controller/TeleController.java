package myjpa.demo.controller;

import myjpa.demo.Linkman;
import myjpa.demo.Table;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Vector;

@Controller
public class TeleController {
    @PostMapping("/checkTele")
    public void checkTele(String tele, HttpServletRequest request, HttpServletResponse response) throws IOException {
        Table t = (Table)request.getSession().getAttribute("table");
        Vector<Linkman> list = t.getTable();
        String flag = "Valid Telephone";
        for(int i=0; i<list.size(); i++){
            //根据姓名匹配要修改的对象
            System.out.println(list.elementAt(i).getTel());
            if(list.elementAt(i).getTel().equals(tele))
                flag = "You have had other linkman using the same phone!";
        }
        response.getWriter().print(flag);
    }
}