function add() {
    var temp = document.createElement("form")
    temp.action = "/add"
    temp.method = "post"
    temp.style.display = "none"
    document.body.appendChild(temp)
    temp.submit()
}
function exit(){
    var temp = document.createElement("form")
    temp.action = "/exit"
    temp.method = "post"
    temp.style.display = "none"
    document.body.appendChild(temp)
    temp.submit()
}
function change(elem) {
    //第一次parentNode得到td标签的位置，第二次parentNode得到tr标签的位置
    var row = elem.parentNode.parentNode.rowIndex
    var tr = elem.parentNode.parentNode
    var tbody = tr.parentNode
    var temp = document.createElement("form")
    temp.action = "/change"
    temp.method = "post"
    temp.style.display = "none"
    var opt = document.createElement("textarea")
    opt.name = "row"
    opt.value = row.toString()
    temp.appendChild(opt)
    document.body.appendChild(temp)
    //找到tr标签后删掉
    tbody.removeChild(tr)
    temp.submit()
}

function del(elem) {
    //第一次parentNode得到td标签的位置，第二次parentNode得到tr标签的位置
    var row = elem.parentNode.parentNode.rowIndex
    var tr = elem.parentNode.parentNode
    var tbody = tr.parentNode
    var temp = document.createElement("form")
    temp.action = "/del"
    temp.method = "post"
    temp.style.display = "none"
    var opt = document.createElement("textarea")
    opt.name = "row"
    opt.value = row.toString()
    temp.appendChild(opt)
    document.body.appendChild(temp)
    //找到tr标签后删掉
    tbody.removeChild(tr)
    temp.submit()
}